const form = document.getElementById("form");

const password = document.getElementById("password");

const strengthBar =
document.getElementById("strengthBar");

const strengthText =
document.getElementById("strengthText");

const togglePassword =
document.getElementById("togglePassword");

const modal =
document.getElementById("successModal");

const closeModal =
document.getElementById("closeModal");

togglePassword.addEventListener("click",()=>{

if(password.type==="password"){
password.type="text";
}
else{
password.type="password";
}

});

password.addEventListener("input",()=>{

let value=password.value;

let strength=0;

if(value.length>=8) strength++;
if(/[A-Z]/.test(value)) strength++;
if(/[a-z]/.test(value)) strength++;
if(/[0-9]/.test(value)) strength++;
if(/[^A-Za-z0-9]/.test(value)) strength++;

if(strength<=2){
strengthBar.style.width="33%";
strengthBar.style.background="red";
strengthText.textContent="Weak Password";
}

else if(strength<=4){
strengthBar.style.width="66%";
strengthBar.style.background="orange";
strengthText.textContent="Medium Password";
}

else{
strengthBar.style.width="100%";
strengthBar.style.background="green";
strengthText.textContent="Strong Password";
}

});

form.addEventListener("submit",(e)=>{

e.preventDefault();

let valid=true;

let name=
document.getElementById("name").value.trim();

let email=
document.getElementById("email").value.trim();

let confirm=
document.getElementById("confirmPassword").value;

document.getElementById("nameError").innerHTML="";
document.getElementById("emailError").innerHTML="";
document.getElementById("passwordError").innerHTML="";
document.getElementById("confirmError").innerHTML="";

if(name.length<3){

document.getElementById("nameError")
.innerHTML="Enter valid name";

valid=false;
}

let emailPattern=
/^[^\s@]+@[^\s@]+\.[^\s@]+$/;

if(!emailPattern.test(email)){

document.getElementById("emailError")
.innerHTML="Invalid email";

valid=false;
}

let passwordPattern=
/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;

if(!passwordPattern.test(password.value)){

document.getElementById("passwordError")
.innerHTML=
"Strong password required";

valid=false;
}

if(confirm!==password.value){

document.getElementById("confirmError")
.innerHTML=
"Passwords do not match";

valid=false;
}

if(valid){

modal.style.display="flex";

form.reset();

strengthBar.style.width="0";

strengthText.innerHTML="";
}

});

closeModal.addEventListener("click",()=>{

modal.style.display="none";

});