/* ==========================
   LOADER
========================== */

window.addEventListener("load", () => {
    const loader = document.getElementById("loader");

    setTimeout(() => {
        loader.style.display = "none";
    }, 1000);
});


/* ==========================
   TYPING EFFECT
========================== */

const words = [
    "Websites",
    "Mobile Apps",
    "AI Solutions",
    "SaaS Products",
    "Digital Platforms"
];

let wordIndex = 0;
let charIndex = 0;

function typeEffect() {

    const typing = document.getElementById("typing");

    if (!typing) return;

    if (charIndex < words[wordIndex].length) {

        typing.textContent +=
            words[wordIndex].charAt(charIndex);

        charIndex++;

        setTimeout(typeEffect, 100);

    } else {

        setTimeout(() => {

            typing.textContent = "";

            charIndex = 0;

            wordIndex++;

            if (wordIndex >= words.length) {
                wordIndex = 0;
            }

            typeEffect();

        }, 1500);

    }

}

typeEffect();


/* ==========================
   DARK MODE
========================== */

const themeBtn =
    document.getElementById("theme-btn");

if (themeBtn) {

    if (localStorage.getItem("theme") === "light") {
        document.body.classList.add("light");
    }

    themeBtn.addEventListener("click", () => {

        document.body.classList.toggle("light");

        if (
            document.body.classList.contains("light")
        ) {

            localStorage.setItem(
                "theme",
                "light"
            );

        } else {

            localStorage.setItem(
                "theme",
                "dark"
            );

        }

    });

}


/* ==========================
   COUNTER ANIMATION
========================== */

const counters =
    document.querySelectorAll(".counter");

counters.forEach(counter => {

    counter.innerText = "0";

    const updateCounter = () => {

        const target =
            +counter.getAttribute("data-target");

        const count =
            +counter.innerText;

        const increment =
            target / 100;

        if (count < target) {

            counter.innerText =
                `${Math.ceil(
                    count + increment
                )}`;

            setTimeout(
                updateCounter,
                20
            );

        } else {

            counter.innerText =
                target;

        }

    };

    updateCounter();

});


/* ==========================
   CONTACT FORM
========================== */

const form =
    document.getElementById(
        "contactForm"
    );

if (form) {

    form.addEventListener(
        "submit",
        (e) => {

            e.preventDefault();

            const name =
                document.getElementById(
                    "name"
                ).value.trim();

            const email =
                document.getElementById(
                    "email"
                ).value.trim();

            const message =
                document.getElementById(
                    "message"
                ).value.trim();

            if (
                name === "" ||
                email === "" ||
                message === ""
            ) {

                alert(
                    "Please fill all fields"
                );

                return;
            }

            const emailPattern =
                /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (
                !emailPattern.test(email)
            ) {

                alert(
                    "Enter a valid email"
                );

                return;
            }

            alert(
                "Message Sent Successfully!"
            );

            form.reset();

        }
    );

}


/* ==========================
   SCROLL TO TOP
========================== */

const topBtn =
    document.getElementById(
        "topBtn"
    );

window.addEventListener(
    "scroll",
    () => {

        if (!topBtn) return;

        if (
            window.scrollY > 300
        ) {

            topBtn.style.display =
                "block";

        } else {

            topBtn.style.display =
                "none";

        }

    }
);

if (topBtn) {

    topBtn.addEventListener(
        "click",
        () => {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        }
    );

}


/* ==========================
   ACTIVE NAV LINK
========================== */

const sections =
    document.querySelectorAll(
        "section"
    );

const navLinks =
    document.querySelectorAll(
        ".nav-links a"
    );

window.addEventListener(
    "scroll",
    () => {

        let current = "";

        sections.forEach(section => {

            const sectionTop =
                section.offsetTop;

            if (
                pageYOffset >=
                sectionTop - 200
            ) {

                current =
                    section.getAttribute(
                        "id"
                    );

            }

        });

        navLinks.forEach(link => {

            link.classList.remove(
                "active"
            );

            if (
                link.href.includes(
                    current
                )
            ) {

                link.classList.add(
                    "active"
                );

            }

        });

    }
);


/* ==========================
   REVEAL ON SCROLL
========================== */

const revealElements =
    document.querySelectorAll(
        ".card, .project, .stat-box"
    );

function reveal() {

    revealElements.forEach(el => {

        const windowHeight =
            window.innerHeight;

        const revealTop =
            el.getBoundingClientRect()
                .top;

        if (
            revealTop <
            windowHeight - 100
        ) {

            el.style.opacity = "1";
            el.style.transform =
                "translateY(0)";

        }

    });

}

revealElements.forEach(el => {

    el.style.opacity = "0";
    el.style.transform =
        "translateY(50px)";
    el.style.transition =
        "all .6s ease";

});

window.addEventListener(
    "scroll",
    reveal
);

reveal();


/* ==========================
   CURRENT YEAR FOOTER
========================== */

const footer =
    document.querySelector(
        "footer p"
    );

if (footer) {

    footer.innerHTML =
        `© ${new Date().getFullYear()}
         CodeSphere Software House.
         All Rights Reserved.`;

}